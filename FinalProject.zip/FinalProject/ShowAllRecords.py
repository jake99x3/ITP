import csv
student_info = ['Student ID', 'First name', 'last name', 'age', 'address', 'phone number']
database = 'file_records.txt'


def show_record():
    global student_info
    global database

    roll = input("Enter a Last Name: ")
    with open(database, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) > 0:
                if roll == row[2]:
                    print("Student ID: ", row[0])
                    print("First Name: ", row[1])
                    print("Last Name: ", row[2])
                    print("Age: ", row[3])
                    print("Address: ", row[4])
                    print("Phone Number: ", row[5])
                    print()
                    break
        else:
            print(f"Record with last name {roll} not found.")
    input("Done! Press enter to continue")
    print('returning to Main Menu')
