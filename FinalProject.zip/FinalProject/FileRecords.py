
from ShowAllRecords import show_record
from deleteRecord import delete_student
from showRecord import view_records
from createRecord import add_record

"""
Fields :- ['Student ID', 'First name', 'Last Name', 'age', 'address', 'phone number']
1. Create a new Record
2. Show a record
3. Delete a record
4. Display All Records.
5. Exit
"""


student_info = ['Student ID', 'First name', 'last name', 'age', 'address', 'phone number']
database = 'file_records.txt'


def display_menu():
    print("**********************************************")
    print("             RECORDS MANAGER    ")
    print("**********************************************")
    print("1. Create a new record. ")
    print("2. Show a record. ")
    print("3. Delete a record. ")
    print("4. Display All Records. ")
    print("5. Exit")


while True:
    display_menu()

    choice = input("Enter your option [1-5]: ")
    if choice == '1':
        print('You have chosen "Create a new record."')
        add_record()
    elif choice == '2':
        print('You have chosen "Show a record"')
        show_record()
    elif choice == '3':
        print('You have chosen "Delete a record". ')
        delete_student()
    elif choice == '4':
        print('You have chosen "Display ALL records in alphabetical order by last name"')
        view_records()
    else:
        print('You have chosen to exit the program. Exiting...')
        break
