import csv
student_info = ['Student ID', 'First name', 'last name', 'age', 'address', 'phone number']
database = 'file_records.txt'


def view_records():
    if input('Would you like the registry sorted alphabetically in Ascending or Descending order? (A or D): ') == "D":

        with open(database, "r", encoding="utf-8") as f:
            for x in student_info:
                print(x, end='\t |')
            print("\n-----------------------------------------------------------------")

            reader = csv.reader(f)
            student_records = sorted(reader, reverse=True, key=lambda r: (r[2], r[1]))
            for row in student_records:
                print(*row, sep="\t |")
    else:
        with open(database, "r", encoding="utf-8") as f:
            for x in student_info:
                print(x, end='\t |')
            print("\n-----------------------------------------------------------------")

            reader = csv.reader(f)
            student_records = sorted(reader, key=lambda r: (r[2], r[1]))
            for row in student_records:
                print(*row, sep="\t |")

    input("Done! Press enter to continue")
    print('returning to Main Menu')
