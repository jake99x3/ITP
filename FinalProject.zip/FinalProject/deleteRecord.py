import csv
student_info = ['Student ID', 'First name', 'last name', 'age', 'address', 'phone number']
database = 'file_records.txt'


def delete_student():
    global student_info
    global database

    roll = input("Enter a Last Name: ")
    student_found = False
    updated_data = []
    with open(database, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        counter = 0
        for row in reader:
            if len(row) > 0:
                if roll != row[2]:
                    updated_data.append(row)
                    counter += 1
                else:
                    student_found = True

    if student_found is True:

        if input(f"Are you sure you want to delete record with Last Name {roll}? Enter Y or N. ") != "Y":
            return()
        with open(database, "w", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerows(updated_data)
    else:
        print(f"Record with last name {roll} not found")

    input("Done! Press enter to continue.")
    print("returning to Main Menu.")
