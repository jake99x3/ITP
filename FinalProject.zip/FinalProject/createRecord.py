import csv
student_info = ['Student ID', 'First name', 'last name', 'age', 'address', 'phone number']
database = 'file_records.txt'


def add_record():

    global student_info
    global database

    student_data = []
    for field in student_info:
        value = input("What is the student's " + field + "? ")
        student_data.append(value)

    with open(database, "a", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows([student_data])

    input("The record has been added to file_records.txt. Press enter to continue.")
    print('returning to Main Menu')
    return
